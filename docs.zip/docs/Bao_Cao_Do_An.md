# BỘ CÔNG THƯƠNG
**ĐẠI HỌC CÔNG NGHIỆP HÀ NỘI**
**KHOA CÔNG NGHỆ THÔNG TIN**

---

# BÁO CÁO ĐỒ ÁN TỐT NGHIỆP

**Đề tài:**
# XÂY DỰNG WEBSITE THƯƠNG MẠI ĐIỆN TỬ
**(CỬA HÀNG THỜI TRANG GABI STORE)**

<br>

**Giáo viên hướng dẫn:** Ths. [Tên Giáo Viên]
**Sinh viên thực hiện:** [Tên Của Bạn]
**Lớp:** [Tên Lớp]
**Mã sinh viên:** [Mã SV]

<br>
<br>

**Hà Nội – 2026**

---

# LỜI CAM ĐOAN

Tôi xin cam đoan đây là công trình nghiên cứu của riêng tôi. Các số liệu, kết quả nêu trong đồ án là trung thực và chưa từng được ai công bố trong bất kỳ công trình nào khác.
Tôi xin chịu hoàn toàn trách nhiệm về nội dung của đồ án này.

Sinh viên thực hiện
(Ký và ghi rõ họ tên)

---

# MỤC LỤC

1.  [CHƯƠNG 1: TỔNG QUAN VỀ ĐỀ TÀI](#chương-1-tổng-quan-về-đề-tài)
    *   1.1. Lý do chọn đề tài
    *   1.2. Mục tiêu nghiên cứu
    *   1.3. Phạm vi nghiên cứu
    *   1.4. Ý nghĩa thực tiễn
2.  [CHƯƠNG 2: CƠ SỞ LÝ THUYẾT VÀ CÔNG NGHỆ](#chương-2-cơ-sở-lý-thuyết-và-công-nghệ)
    *   2.1. Tổng quan về Web App và kiến trúc Client-Server
    *   2.2. Frontend Framework: ReactJS
    *   2.3. Backend Framework: NestJS
    *   2.4. Hệ quản trị Cơ sở dữ liệu MySQL
    *   2.5. Các công nghệ hỗ trợ khác (Redux, Tailwind, Swagger)
3.  [CHƯƠNG 3: PHÂN TÍCH VÀ THIẾT KẾ HỆ THỐNG](#chương-3-phân-tích-và-thiết-kế-hệ-thống)
    *   3.1. Đặc tả yêu cầu hệ thống
    *   3.2. Biểu đồ Use Case chi tiết
    *   3.3. Thiết kế Cơ sở dữ liệu (ERD)
    *   3.4. Thiết kế kiến trúc hệ thống
4.  [CHƯƠNG 4: TRIỂN KHAI VÀ XÂY DỰNG ỨNG DỤNG](#chương-4-triển-khai-và-xây-dựng-ứng-dụng)
    *   4.1. Môi trường và công cụ phát triển
    *   4.2. Cấu trúc dự án (Project Structure)
    *   4.3. Xây dựng các module chính
    *   4.4. Giao diện chương trình và Demo
5.  [CHƯƠNG 5: KẾT QUẢ ĐẠT ĐƯỢC VÀ HƯỚNG PHÁT TRIỂN](#chương-5-kết-quả-đạt-được-và-hướng-phát-triển)
    *   5.1. Kết quả đạt được
    *   5.2. Hạn chế
    *   5.3. Hướng phát triển trong tương lai
6.  [TÀI LIỆU THAM KHẢO](#tài-liệu-tham-khảo)

---

# DANH MỤC HÌNH ẢNH

*   Hình 2.1: Mô hình hoạt động của ReactJS (Virtual DOM)
*   Hình 2.2: Kiến trúc Modularity của NestJS
*   Hình 3.1: Sơ đồ Use Case tổng quát của hệ thống
*   Hình 3.2: Sơ đồ Use Case phân hệ Khách hàng
*   Hình 3.3: Sơ đồ Use Case phân hệ Quản trị viên
*   Hình 3.4: Sơ đồ Thực thể liên kết (ERD)
*   Hình 4.1: Cấu trúc thư mục dự án
*   Hình 4.2: Giao diện Trang chủ (Home Page)
*   Hình 4.3: Giao diện Danh sách sản phẩm (Filter & Search)
*   Hình 4.4: Giao diện Chi tiết sản phẩm
*   Hình 4.5: Giao diện Giỏ hàng (Cart)
*   Hình 4.6: Quy trình thanh toán (Checkout)
*   Hình 4.7: Giao diện Dashboard quản trị

---

# CHƯƠNG 1: TỔNG QUAN VỀ ĐỀ TÀI

## 1.1. Lý do chọn đề tài
Trong kỷ nguyên số hóa, thương mại điện tử (E-commerce) không còn là xu hướng mà đã trở thành phương thức mua sắm thiết yếu. Theo báo cáo của Hiệp hội Thương mại điện tử Việt Nam (VECOM), tốc độ tăng trưởng trung bình của thị trường này đạt trên 25% mỗi năm.
Đối với ngành hàng thời trang, tính trực quan về hình ảnh và sự tiện lợi trong việc so sánh giá cả, mẫu mã là yếu tố then chốt thu hút khách hàng. Một cửa hàng truyền thống (Offline) bị giới hạn bởi không gian địa lý và thời gian hoạt động, trong khi một website bán hàng có thể hoạt động 24/7 và tiếp cận khách hàng toàn cầu.
Xuất phát từ nhu cầu thực tế đó, cùng với mong muốn áp dụng các công nghệ lập trình web hiện đại (Fullstack JS) vào giải quyết bài toán kinh doanh, em đã lựa chọn đề tài **"Xây dựng Website thương mại điện tử - Cửa hàng thời trang Gabi Store"**.

## 1.2. Mục tiêu nghiên cứu
Đồ án tập trung vào các mục tiêu chính sau:
1.  **Nghiên cứu công nghệ:** Tìm hiểu sâu về ReactJS cho Frontend và NestJS cho Backend, cách kết hợp chúng để tạo ra một ứng dụng SPA (Single Page Application) hiệu năng cao.
2.  **Xây dựng quy trình nghiệp vụ:** Phân tích quy trình mua hàng chuẩn từ khâu tìm kiếm, lựa chọn, đặt hàng đến thanh toán và theo dõi đơn hàng.
3.  **Phát triển sản phẩm:** Tạo ra một website hoàn chỉnh, giao diện thân thiện (User-friendly), chuẩn Responsive (tương thích mobile/desktop) và có hệ thống quản trị dữ liệu tập trung.

## 1.3. Phạm vi nghiên cứu
*   **Không gian:** Hệ thống hoạt động trên môi trường Web.
*   **Đối tượng phục vụ:**
    *   Khách hàng mua lẻ (B2C).
    *   Quản trị viên cửa hàng.
*   **Chức năng chính:** Quản lý sản phẩm, danh mục, thương hiệu, người dùng, đơn hàng, và blog tin tức.

## 1.4. Ý nghĩa thực tiễn
Sản phẩm của đồ án có thể được triển khai thực tế cho các cửa hàng thời trang vừa và nhỏ, giúp họ:
*   Tiết kiệm chi phí thuê mặt bằng và nhân sự.
*   Quản lý kho hàng và doanh thu chính xác, minh bạch.
*   Nâng cao hình ảnh thương hiệu chuyên nghiệp trong mắt khách hàng.

---

# CHƯƠNG 2: CƠ SỞ LÝ THUYẾT VÀ CÔNG NGHỆ

## 2.1. Tổng quan về Web App và kiến trúc Client-Server
Hệ thống được xây dựng theo mô hình **Client-Server** tách biệt (Decoupled Architecture):
*   **Client (Frontend):** Chịu trách nhiệm hiển thị giao diện, tương tác với người dùng và gọi API.
*   **Server (Backend):** Chịu trách nhiệm xử lý logic nghiệp vụ, xác thực, phân quyền và tương tác với Cơ sở dữ liệu.
Hai thành phần này giao tiếp với nhau thông qua **RESTful API** sử dụng định dạng dữ liệu **JSON**.

## 2.2. Frontend Framework: ReactJS
**2.2.1. Giới thiệu**
ReactJS là thư viện JavaScript phổ biến nhất thế giới hiện nay, được phát triển bởi Facebook (Meta).
**2.2.2. Đặc điểm nổi bật**
*   **Component-based:** Ứng dụng được chia nhỏ thành các thành phần độc lập (Header, Footer, ProductCard...), dễ dàng tái sử dụng và bảo trì.
*   **Virtual DOM:** React tạo ra một bản sao ảo của DOM. Khi có thay đổi dữ liệu, nó so sánh Virtual DOM mới với cái cũ và chỉ cập nhật những phần thực sự thay đổi trên DOM thật, giúp tối ưu hiệu suất render đáng kể.
*   **SPA (Single Page Application):** Trang web không cần tải lại hoàn toàn khi chuyển trang, mang lại trải nghiệm mượt mà.

## 2.3. Backend Framework: NestJS
**2.3.1. Giới thiệu**
NestJS là một framework Node.js tiến bộ (progressive) dùng để xây dựng các ứng dụng server-side hiệu quả và dễ mở rộng. Nó sử dụng TypeScript làm ngôn ngữ chính.
**2.3.2. Tại sao chọn NestJS?**
*   **Kiến trúc rõ ràng:** NestJS cung cấp cấu trúc code chuẩn mực (Controllers, Providers, Modules) giống như Angular, giúp code dễ đọc và dễ làm việc nhóm.
*   **Dependency Injection (DI):** Cơ chế quản lý sự phụ thuộc tự động, giúp các module liên kết lỏng lẻo (loose coupling), dễ dàng kiểm thử (Unit Test).
*   **Hỗ trợ ORM:** Tích hợp tốt với TypeORM và Sequelize.

## 2.4. Hệ quản trị Cơ sở dữ liệu MySQL & Sequelize
*   **MySQL:** RDBMS phổ biến, phù hợp cho các dữ liệu có cấu trúc quan hệ chặt chẽ như Đơn hàng - Sản phẩm - Khách hàng. Đảm bảo tính toàn vẹn dữ liệu (ACID).
*   **Sequelize ORM:** Là cầu nối giúp lập trình viên thao tác với Database bằng mã nguồn JavaScript/TypeScript thay vì viết câu lệnh SQL trần. Nó hỗ trợ Migration (quản lý phiên bản DB) và Seeder (tạo dữ liệu mẫu).

## 2.5. Các công nghệ hỗ trợ khác
*   **Redux Toolkit:** Quản lý trạng thái toàn cục (State Management). Ví dụ: Trạng thái giỏ hàng được lưu trữ trong Redux Store để có thể truy cập từ bất kỳ component nào.
*   **Tailwind CSS:** Framework CSS ưu tiên tiện ích, giúp xây dựng giao diện nhanh chóng mà không cần viết nhiều file CSS tùy chỉnh.
*   **Swagger:** Công cụ tự động sinh tài liệu API, giúp Frontend và Backend dễ dàng giao tiếp và kiểm thử API.

---

# CHƯƠNG 3: PHÂN TÍCH VÀ THIẾT KẾ HỆ THỐNG

## 3.1. Đặc tả yêu cầu hệ thống
### 3.1.1. Yêu cầu chức năng
**A. Phân hệ Khách hàng (Front-office)**
1.  **Đăng ký/Đăng nhập:** Đăng ký tài khoản qua Email, đăng nhập để lưu lịch sử mua hàng.
2.  **Tìm kiếm & Lọc:** Tìm sản phẩm theo tên, danh mục (Áo, Quần, Phụ kiện), mức giá, thương hiệu.
3.  **Giỏ hàng:** Thêm sản phẩm, cập nhật số lượng, xóa sản phẩm, hiển thị tạm tính.
4.  **Đặt hàng (Checkout):** Nhập thông tin giao hàng, chọn phương thức thanh toán (Tiền mặt/PayPal), xác nhận đơn hàng.
5.  **Theo dõi đơn hàng:** Xem trạng thái đơn hàng (Chờ xác nhận, Đang giao, Đã giao).

**B. Phân hệ Quản trị (Back-office)**
1.  **Quản lý Thống kê:** Xem doanh thu, số đơn hàng, số khách hàng mới theo thời gian.
2.  **Quản lý Sản phẩm:** Thêm mới, sửa thông tin, xóa sản phẩm, quản lý ảnh sản phẩm.
3.  **Quản lý Danh mục & Thương hiệu.**
4.  **Quản lý Đơn hàng:** Duyệt đơn, cập nhật trạng thái đơn (Ví dụ: Từ "Chờ xử lý" -> "Đang giao").

### 3.1.2. Yêu cầu phi chức năng
*   **Hiệu năng:** Tốc độ tải trang chủ dưới 3 giây.
*   **Bảo mật:** Mật khẩu người dùng phải được mã hóa (Hash) trước khi lưu. API phải có cơ chế xác thực (JWT).
*   **Giao diện:** Thân thiện, dễ dùng, hiển thị tốt trên Mobile.

## 3.2. Thiết kế Cơ sở dữ liệu (ERD)
Cơ sở dữ liệu bao gồm các thực thể chính sau:

1.  **Bảng `Users`**:
    *   `id`: Khóa chính.
    *   `email`: Tên đăng nhập.
    *   `password`: Mật khẩu đã mã hóa.
    *   `role`: Quyền hạn (Admin/User).
2.  **Bảng `Products`**:
    *   `id`: Khóa chính.
    *   `name`: Tên sản phẩm.
    *   `price`: Giá bán.
    *   `description`: Mô tả chi tiết (HTML).
    *   `thumb`: Ảnh đại diện.
    *   `category_id`: Khóa ngoại liên kết bảng Categories.
3.  **Bảng `Product_Images`**: Lưu danh sách ảnh chi tiết của sản phẩm.
4.  **Bảng `Orders`**:
    *   `id`: Khóa chính.
    *   `user_id`: Người đặt hàng.
    *   `total`: Tổng tiền.
    *   `status`: Trạng thái (Pending, Processing, Completed, Cancelled).
    *   `address`, `mobile`: Thông tin nhận hàng.
5.  **Bảng `Order_Details`**:
    *   `order_id`: Thuộc đơn hàng nào.
    *   `product_id`: Sản phẩm nào.
    *   `quantity`: Số lượng mua.
    *   `price`: Giá tại thời điểm mua.

---

# CHƯƠNG 4: TRIỂN KHAI VÀ XÂY DỰNG ỨNG DỤNG

## 4.1. Môi trường và công cụ phát triển
*   **Hệ điều hành:** Windows 10/11.
*   **IDE:** Visual Studio Code.
*   **NodeJS:** Version 18.x.
*   **Database:** MySQL Workbench / Docker Container.
*   **Version Control:** Git & GitHub.

## 4.3. Xây dựng các module chính
### 4.3.1. Module Xác thực (Auth)
Sử dụng thư viện `Passport.js` và `JWT`.
*   Khi người dùng đăng nhập thành công, Server trả về `accessToken` và `refreshToken`.
*   Client lưu token vào `localStorage`.
*   Mỗi request gửi lên Server đều đính kèm token trong Header `Authorization: Bearer <token>` để xác thực.

### 4.3.2. Module Giỏ hàng (Cart Logic)
Logic giỏ hàng được xử lý ở Frontend và đồng bộ về Server (nếu người dùng đã đăng nhập).
*   Sử dụng **Redux Slice** `cartSlice` để lưu mảng `cartItems`.
*   Hàm `addToCart`: Kiểm tra sản phẩm đã có trong giỏ chưa. Nếu có -> tăng số lượng. Nếu chưa -> push vào mảng.
*   Hàm `totalPrice`: Dùng hàm `reduce()` để tính tổng tiền: `items.reduce((total, item) => total + item.price * item.quantity, 0)`.

### 4.3.3. Module Thanh toán (Payment)
Tích hợp PayPal SDK.
*   Tạo App trên PayPal Developer Dashboard để lấy Client ID.
*   Sử dụng component `<PayPalButtons />` để render nút thanh toán.
*   Sự kiện `onApprove`: Khi thanh toán thành công, gọi API `createOrder` để lưu đơn hàng vào Database với trạng thái "Đã thanh toán".

## 4.4. Giao diện chương trình và Demo
*(Phần này mô tả chi tiết bằng lời các màn hình)*
*   **Trang chủ:** Thiết kế Banner lớn trình chiếu các bộ sưu tập mới nhất. Bên dưới là các section "Best Seller", "New Arrivals" dạng lưới (Grid).
*   **Trang Sản phẩm:** Có Sidebar bên trái chứa các bộ lọc (Filter) theo checkbox. Dữ liệu được fetch từ API thông qua React Hook `useEffect` và quản lý params trên URL.
*   **Trang Admin:** Sử dụng Layout riêng biệt. Bảng danh sách sản phẩm có tính năng Phân trang (Pagination) server-side để tối ưu tốc độ khi dữ liệu lớn.

---

# CHƯƠNG 5: KẾT QUẢ ĐẠT ĐƯỢC VÀ HƯỚNG PHÁT TRIỂN

## 5.1. Kết quả đạt được
Sau thời gian thực hiện, đồ án đã hoàn thành được khoảng 90% khối lượng công việc đề ra:
1.  Website hoạt động trơn tru, không phát sinh lỗi nghiêm trọng.
2.  Giải quyết triệt để vấn đề hiển thị tiếng Việt (lỗi font/mojibake) đã gặp phải trong giai đoạn đầu.
3.  Cấu trúc mã nguồn (Source code) được tổ chức khoa học, tách bạch Frontend và Backend, dễ dàng cho người khác tiếp nhận và phát triển tiếp.

## 5.2. Hạn chế
*   Chưa tích hợp tính năng gửi Email xác nhận đơn hàng tự động.
*   Giao diện Admin còn khá đơn giản, chưa có nhiều biểu đồ thống kê trực quan (Chart).
*   Chưa có tính năng đánh giá/bình luận sản phẩm từ người dùng.

## 5.3. Hướng phát triển trong tương lai
Để phát triển đồ án thành một sản phẩm thương mại hoàn thiện, em dự kiến thực hiện các công việc sau:
1.  **Nâng cấp AI Chatbot:** Tích hợp Chatbot tư vấn size và phối đồ tự động cho khách hàng.
2.  **Mobile App:** Xây dựng ứng dụng di động bằng React Native, dùng chung Backend API hiện có.
3.  **Tối ưu SEO:** Cải thiện SEO bằng cách chuyển đổi sang Next.js (Server Side Rendering) để google bot dễ dàng index nội dung.

---

# TÀI LIỆU THAM KHẢO

1.  *NestJS Documentation*. [Online]. Available: https://docs.nestjs.com/
2.  *React Documentation*. [Online]. Available: https://react.dev/
3.  *Sequelize ORM Manual*. [Online]. Available: https://sequelize.org/
4.  *Khóa học Fullstack Web Development - F8 / Udemy.*
