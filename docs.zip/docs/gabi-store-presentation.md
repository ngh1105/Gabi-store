# GABI-STORE
## Ứng Dụng Web Thương Mại Điện Tử

**Công Nghệ:**
ReactJS + NestJS + MySQL

---

## 📋 Mục Tiêu Hệ Thống

### Mục Đích Chính
Xây dựng nền tảng thương mại điện tử đầy đủ tính năng, hiện đại và dễ sử dụng cho cả người mua và người quản trị.

### Giải Pháp Cung Cấp
- 🛍️ **Trải nghiệm mua sắm trực tuyến** hoàn chỉnh
- 💳 **Thanh toán an toàn** qua PayPal
- 📊 **Quản lý hiệu quả** sản phẩm và đơn hàng
- 🔐 **Bảo mật cao** với JWT Authentication
- 📱 **Giao diện responsive** trên mọi thiết bị

### Đối Tượng Sử Dụng
- **Khách hàng:** Người mua sắm trực tuyến
- **Quản trị viên:** Nhân viên quản lý cửa hàng
- **Admin:** Quản trị hệ thống

---

## 🏗️ Kiến Trúc Hệ Thống

![System Architecture](./images/gabi_store_architecture_1769613970540.png)

### Các Lớp Chính

**Frontend Layer**
- ReactJS + TailwindCSS cho giao diện người dùng
- Redux Toolkit quản lý state toàn cục
- React Router điều hướng trang
- Tích hợp PayPal SDK

**API Layer**
- RESTful API chuẩn REST
- JWT Authentication bảo mật
- Middleware xử lý request/response

**Backend Layer**
- NestJS framework với architecture modules
- 8 modules chính: Products, Cart, Orders, Users, Payments, Blog, Wishlist, Rating
- Sequelize ORM tương tác database

**Database Layer**
- MySQL lưu trữ dữ liệu quan hệ
- Cấu trúc bảng được tối ưu hóa

---

## 💻 Công Nghệ & Tech Stack

![Technology Stack](./images/tech_stack_visual_1769614965139.png)

### Frontend Technologies
- **ReactJS 18.2** - Thư viện UI hiện đại
- **TailwindCSS 3.3** - Utility-first CSS framework
- **Redux Toolkit** - State management
- **React Router v6** - Client-side routing
- **Axios** - HTTP client
- **PayPal React SDK** - Thanh toán online

### Backend Technologies
- **NestJS** - Progressive Node.js framework
- **TypeScript** - Type-safe programming
- **Sequelize** - ORM cho MySQL
- **JWT** - JSON Web Tokens authentication
- **Bcrypt** - Password hashing

### Database & Tools
- **MySQL** - Relational database
- **Git** - Version control
- **npm** - Package manager

---

## 🌐 Giao Diện Người Dùng

![Homepage Design](./images/gabi_store_homepage_1769614217233.png)

### Tính Năng Chính

**Trang Chủ**
- Hero banner với collection mới nhất
- Danh mục sản phẩm (carousel)
- Sản phẩm nổi bật
- Tìm kiếm thông minh

**Xem Sản Phẩm**
- Lọc theo danh mục, giá, thương hiệu
- Xem chi tiết đầy đủ
- Hình ảnh sản phẩm chất lượng cao
- Đánh giá & rating từ người dùng

**Giỏ Hàng**
- Thêm/sửa/xóa sản phẩm
- Cập nhật số lượng real-time
- Tính tổng tiền tự động
- Mã giảm giá (nếu có)

---

## 🛒 Chức Năng Khách Hàng

### Quy Trình Mua Hàng

1. **Duyệt & Chọn Sản Phẩm**
   - Xem catalog sản phẩm
   - Tìm kiếm & lọc nâng cao
   - Xem chi tiết sản phẩm

2. **Quản Lý Giỏ Hàng**
   - Thêm sản phẩm vào giỏ
   - Điều chỉnh số lượng
   - Xóa sản phẩm không cần

3. **Đặt Hàng & Thanh Toán**
   - Nhập thông tin giao hàng
   - Chọn phương thức thanh toán
   - Thanh toán qua PayPal
   - Nhận email xác nhận

4. **Theo Dõi Đơn Hàng**
   - Xem lịch sử mua hàng
   - Kiểm tra trạng thái đơn
   - Đánh giá sản phẩm đã mua

### Tính Năng Bổ Sung
- 💝 **Wishlist** - Lưu sản phẩm yêu thích
- ⭐ **Rating** - Đánh giá sản phẩm
- 🔔 **Blog** - Đọc tin tức, khuyến mãi
- 👤 **Profile** - Quản lý tài khoản

---

## 💳 Luồng Thanh Toán

![Payment Flow](./images/payment_flow_diagram_1769614663976.png)

### Chi Tiết Quy Trình

**Bước 1: Khách hàng chọn sản phẩm**
- Browse products → Add to cart → Checkout

**Bước 2: Chọn phương thức thanh toán**
- PayPal (tích hợp sẵn)
- Các phương thức khác (mở rộng sau)

**Bước 3: Xử lý thanh toán**
- Gọi PayPal API
- Xác thực giao dịch
- Nhận thông báo kết quả

**Bước 4: Xử lý kết quả**
- ✅ **Thành công:** Tạo đơn hàng → Gửi email xác nhận → Hoàn tất
- ❌ **Thất bại:** Quay lại chọn phương thức → Thử lại

### Bảo Mật
- HTTPS cho mọi giao dịch
- PayPal SDK chính thức
- Không lưu trữ thông tin thẻ
- JWT token cho authentication

---

## 🎛️ Giao Diện Quản Trị

![Admin Dashboard](./images/gabi_admin_dashboard_1769614471517.png)

### Dashboard Tổng Quan

**Thống Kê Chính**
- 💰 Total Revenue - Doanh thu tổng
- 📦 Total Orders - Số đơn hàng
- 👥 Active Users - Người dùng hoạt động
- 🏷️ Products - Số sản phẩm

**Biểu Đồ**
- Sales Overview (doanh thu theo tháng)
- Xu hướng tăng trưởng
- So sánh theo thời gian

**Recent Orders**
- Danh sách đơn hàng gần nhất
- Trạng thái: Pending, Shipped, Delivered
- Actions: View, Edit đơn hàng

---

## 🔧 Chức Năng Quản Trị

### Quản Lý Sản Phẩm
- ➕ **Thêm mới** sản phẩm với đầy đủ thông tin
- ✏️ **Chỉnh sửa** thông tin, giá cả, hình ảnh
- 🗑️ **Xóa** sản phẩm không còn kinh doanh
- 📊 **Quản lý tồn kho** - cập nhật số lượng
- 🏷️ **Phân loại** theo danh mục, thương hiệu

### Quản Lý Đơn Hàng
- 📋 **Xem danh sách** tất cả đơn hàng
- 🔄 **Cập nhật trạng thái:**
  - Chờ xử lý → Đang giao → Hoàn thành
- 📧 **Thông báo** cho khách hàng
- 🚫 **Hủy đơn** (nếu cần)
- 📊 **Báo cáo** doanh thu

### Quản Lý Người Dùng
- 👥 **Danh sách** người dùng
- 🔒 **Khóa/mở khóa** tài khoản
- 👑 **Phân quyền** (user, admin)
- 📊 **Xem lịch sử** mua hàng của user

### Quản Lý Nội Dung
- 📝 **Blog posts** - tin tức, khuyến mãi
- 🏷️ **Categories** - danh mục sản phẩm
- 🏢 **Brands** - thương hiệu
- 💬 **Comments** - bình luận, đánh giá

---

## 🔐 Bảo Mật & Xác Thực

### Authentication Flow
```
User Login → Validate Credentials → Generate JWT → Store in Cookie/LocalStorage
↓
Protected Routes → Verify JWT → Allow/Deny Access
```

### Security Features
- 🔑 **JWT Tokens** - Stateless authentication
- 🔒 **Bcrypt Password Hashing** - Mã hóa mật khẩu
- 🛡️ **Role-Based Access Control** - Phân quyền theo vai trò
- 🚪 **Protected Routes** - Route guards
- 🔄 **Token Refresh** - Tự động gia hạn session
- ⏱️ **Session Timeout** - Timeout tự động

### Data Protection
- ✅ Input validation và sanitization
- ✅ SQL injection prevention (Sequelize ORM)
- ✅ XSS protection
- ✅ CORS configuration
- ✅ HTTPS enforcement (production)

---

## 📁 Cấu Trúc Dự Án

### Frontend Structure
```
frontend/
├── src/
│   ├── components/     # Reusable components
│   ├── pages/          # Page components
│   │   ├── public/    # Public pages (Home, Products)
│   │   └── admin/     # Admin pages (Dashboard)
│   ├── layouts/        # Layout components
│   ├── redux/          # Redux store & slices
│   ├── routes/         # Route configuration
│   ├── hooks/          # Custom hooks
│   └── app/            # App config & API
├── public/             # Static assets
└── package.json
```

### Backend Structure
```
backend/
├── src/
│   ├── auth/           # Authentication module
│   ├── user/           # User management
│   ├── product/        # Product CRUD
│   ├── category/       # Category management
│   ├── brand/          # Brand management
│   ├── bill/           # Order management
│   ├── bill-detail/    # Order details
│   ├── blog/           # Blog posts
│   ├── comment/        # Comments
│   ├── rating/         # Ratings
│   ├── wishlist/       # Wishlist
│   ├── mail/           # Email service
│   └── database/       # DB configuration
└── package.json
```

---

## 🚀 Triển Khai & Chạy Ứng Dụng

### Yêu Cầu Hệ Thống
- Node.js ≥ 16.x
- npm ≥ 8.x
- MySQL ≥ 8.0
- Git

### Cài Đặt & Cấu Hình

**1. Clone repository**
```bash
git clone <repository-url>
cd gabi-store
```

**2. Cài đặt Backend**
```bash
cd backend
npm install
# Cấu hình .env (database, JWT secret, PayPal keys)
npm run start:dev
```

**3. Cài đặt Frontend**
```bash
cd frontend
npm install
# Cấu hình API endpoint
npm start
```

**4. Truy cập**
- Frontend: http://localhost:3000
- Backend API: http://localhost:4000

### Triển Khai Production
- Build frontend: `npm run build`
- Build backend: `npm run build`
- Deploy lên VPS/Cloud (AWS, DigitalOcean, Heroku)
- Cấu hình Nginx reverse proxy
- SSL certificate với Let's Encrypt

---

## ✨ Tính Năng Nổi Bật

### Ưu Điểm Của Gabi-Store

**🎨 Giao Diện Hiện Đại**
- Thiết kế đẹp mắt với TailwindCSS
- Responsive trên mọi thiết bị
- UX/UI thân thiện người dùng

**⚡ Hiệu Năng Cao**
- React optimized rendering
- Lazy loading cho images
- API caching & optimization

**🔒 Bảo Mật Tốt**
- JWT authentication
- Password encryption
- Protected routes & API endpoints

**💳 Thanh Toán Linh Hoạt**
- Tích hợp PayPal chính thức
- Dễ dàng mở rộng payment methods
- Transaction history tracking

**📊 Quản Trị Mạnh Mẽ**
- Dashboard trực quan
- Real-time statistics
- Comprehensive management tools

**🔧 Dễ Bảo Trì & Mở Rộng**
- Clean code architecture
- Modular design (NestJS)
- Well-documented codebase
- TypeScript type safety

---

## 📊 Demo & Kết Luận

### Các Tính Năng Đã Triển Khai ✅

**Phía Khách Hàng**
- ✅ Xem & tìm kiếm sản phẩm
- ✅ Giỏ hàng đầy đủ
- ✅ Đặt hàng & thanh toán PayPal
- ✅ Quản lý tài khoản
- ✅ Lịch sử đơn hàng
- ✅ Wishlist & Rating

**Phía Admin**
- ✅ Dashboard thống kê
- ✅ Quản lý sản phẩm (CRUD)
- ✅ Quản lý đơn hàng
- ✅ Quản lý người dùng
- ✅ Quản lý danh mục & thương hiệu
- ✅ Quản lý blog

### Hướng Phát Triển 🚀

**Tính Năng Mới**
- 💬 Live chat support
- 🔔 Push notifications
- 📱 Mobile app (React Native)
- 🎯 AI product recommendations
- 📧 Email marketing automation

**Cải Tiến Kỹ Thuật**
- 🐳 Docker containerization
- ☸️ Kubernetes orchestration
- 📊 Advanced analytics & reporting
- 🔍 Elasticsearch for search
- 💾 Redis caching layer

### Kết Luận

**Gabi-Store** là một nền tảng thương mại điện tử đầy đủ tính năng, được xây dựng với công nghệ hiện đại và kiến trúc vững chắc. Hệ thống có khả năng mở rộng tốt và sẵn sàng cho môi trường production.

---

## 🙏 Cảm ơn!

### Liên Hệ & Thông Tin

**Project:** Gabi-Store E-Commerce Platform

**Tech Stack:** ReactJS • NestJS • MySQL • TypeScript

**Repository:** [GitHub Link]

**Documentation:** [Docs Link]

---

**Q&A Session**

*Mọi câu hỏi xin vui lòng đặt tại đây!*
