from docx import Document
from docx.shared import Inches, Pt, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn

def add_heading(doc, text, level):
    h = doc.add_heading(text, level=level)
    run = h.runs[0]
    run.font.name = 'Times New Roman'
    run.font.color.rgb = None # default color
    if level == 0:
        h.alignment = WD_ALIGN_PARAGRAPH.CENTER

document = Document()

# Set default font
style = document.styles['Normal']
font = style.font
font.name = 'Times New Roman'
font.size = Pt(13)

# --- TITLE PAGE ---
p = document.add_paragraph('BỘ CÔNG THƯƠNG')
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.runs[0].bold = True
p = document.add_paragraph('ĐẠI HỌC CÔNG NGHIỆP HÀ NỘI')
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.runs[0].bold = True
p = document.add_paragraph('KHOA CÔNG NGHỆ THÔNG TIN')
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.runs[0].bold = True

document.add_paragraph('\n\n\n')

p = document.add_paragraph('BÁO CÁO ĐỒ ÁN TỐT NGHIỆP')
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.runs[0].bold = True
p.runs[0].font.size = Pt(24)

document.add_paragraph('\n')

p = document.add_paragraph('Đề tài:')
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.runs[0].italic = True

p = document.add_paragraph('XÂY DỰNG WEBSITE THƯƠNG MẠI ĐIỆN TỬ')
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.runs[0].bold = True
p.runs[0].font.size = Pt(18)

p = document.add_paragraph('(CỬA HÀNG THỜI TRANG GABI STORE)')
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.runs[0].bold = True
p.runs[0].font.size = Pt(16)

document.add_paragraph('\n\n\n\n')

p = document.add_paragraph('Giáo viên hướng dẫn: Ths. [Tên Giáo Viên]')
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p = document.add_paragraph('Sinh viên thực hiện: [Tên Của Bạn]')
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p = document.add_paragraph('Lớp: [Tên Lớp]')
p.alignment = WD_ALIGN_PARAGRAPH.CENTER

document.add_paragraph('\n\n\n')

p = document.add_paragraph('Hà Nội – 2026')
p.alignment = WD_ALIGN_PARAGRAPH.CENTER

document.add_page_break()

# --- CAM DOAN ---
add_heading(document, 'LỜI CAM ĐOAN', level=1)
document.add_paragraph('Tôi xin cam đoan đây là công trình nghiên cứu của riêng tôi. Các số liệu, kết quả nêu trong đồ án là trung thực và chưa từng được ai công bố trong bất kỳ công trình nào khác.')
document.add_paragraph('\n')
p = document.add_paragraph('Sinh viên thực hiện')
p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
p.runs[0].bold = True
p = document.add_paragraph('(Ký và ghi rõ họ tên)')
p.alignment = WD_ALIGN_PARAGRAPH.RIGHT

document.add_page_break()

# --- MUC LUC ---
add_heading(document, 'MỤC LỤC', level=1)
document.add_paragraph('1. CHƯƠNG 1: TỔNG QUAN')
document.add_paragraph('    1.1. Lý do chọn đề tài')
document.add_paragraph('    1.2. Mục tiêu nghiên cứu')
document.add_paragraph('    1.3. Phạm vi nghiên cứu')
document.add_paragraph('2. CHƯƠNG 2: CƠ SỞ LÝ THUYẾT')
document.add_paragraph('    2.1. Tổng quan về Web App và SPA')
document.add_paragraph('    2.2. ReactJS Framework')
document.add_paragraph('    2.3. NestJS Framework')
document.add_paragraph('    2.4. Hệ quản trị CSDL MySQL')
document.add_paragraph('3. CHƯƠNG 3: PHÂN TÍCH VÀ THIẾT KẾ HỆ THỐNG')
document.add_paragraph('    3.1. Đặc tả yêu cầu (Use Case)')
document.add_paragraph('    3.2. Biểu đồ Use Case')
document.add_paragraph('    3.3. Thiết kế Cơ sở dữ liệu (ERD)')
document.add_paragraph('4. CHƯƠNG 4: TRIỂN KHAI VÀ ĐÁNH GIÁ')
document.add_paragraph('    4.1. Môi trường cài đặt')
document.add_paragraph('    4.2. Giao diện chương trình')
document.add_paragraph('    4.3. Kết quả đạt được')
document.add_paragraph('5. CHƯƠNG 5: KẾT LUẬN')
document.add_paragraph('    5.1. Kết luận chung')
document.add_paragraph('    5.2. Hướng phát triển')

document.add_page_break()

# --- CHAPTER 1 ---
add_heading(document, 'CHƯƠNG 1: TỔNG QUAN', level=1)

add_heading(document, '1.1. Lý do chọn đề tài', level=2)
document.add_paragraph('Ngày nay, Thương mại điện tử (E-Commerce) đã trở thành một phần không thể thiếu trong nền kinh tế số. Việc sở hữu một website bán hàng không chỉ giúp doanh nghiệp tiếp cận khách hàng rộng rãi mà còn tối ưu hóa quy trình quản lý.')
document.add_paragraph('Với mong muốn áp dụng những kiến thức đã học về lập trình Fullstack vào thực tế, em lựa chọn đề tài "Xây dựng Website bán hàng thời trang Gabi Store". Đây là cơ hội để tìm hiểu sâu về các công nghệ hiện đại như ReactJS, NestJS và quy trình phát triển phần mềm chuyên nghiệp.')

add_heading(document, '1.2. Mục tiêu nghiên cứu', level=2)
document.add_paragraph('- Xây dựng hệ thống website bán hàng hoàn chỉnh với đầy đủ các tính năng: Xem sản phẩm, Tìm kiếm, Giỏ hàng, Đặt hàng, Thanh toán.')
document.add_paragraph('- Xây dựng trang quản trị (Admin) để quản lý sản phẩm, đơn hàng, khách hàng.')
document.add_paragraph('- Tối ưu hóa trải nghiệm người dùng (UI/UX) và hiệu năng hệ thống.')

add_heading(document, '1.3. Phạm vi nghiên cứu', level=2)
document.add_paragraph('- Về nghiệp vụ: Tập trung vào qui trình bán lẻ thời trang (B2C).')
document.add_paragraph('- Về công nghệ: Sử dụng JavaScript/TypeScript trên cả Client và Server (Node.js).')

# --- CHAPTER 2 ---
add_heading(document, 'CHƯƠNG 2: CƠ SỞ LÝ THUYẾT', level=1)

add_heading(document, '2.1. Tổng quan về Web App và SPA', level=2)
document.add_paragraph('Single Page Application (SPA) là ứng dụng web tải một trang HTML duy nhất và cập nhật động nội dung trang đó khi người dùng tương tác. Điều này giúp trải nghiệm mượt mà giống như đang dùng ứng dụng desktop, giảm tải băng thông server.')

add_heading(document, '2.2. ReactJS Framework', level=2)
document.add_paragraph('ReactJS là thư viện JavaScript phổ biến nhất hiện nay để xây dựng giao diện người dùng.')
document.add_paragraph('- Component-based: Chia nhỏ UI thành các thành phần độc lập, dễ tái sử dụng.')
document.add_paragraph('- Virtual DOM: Tối ưu hiệu suất render.')
document.add_paragraph('- Unidirectional Data Flow: Luồng dữ liệu một chiều giúp dễ kiểm soát trạng thái ứng dụng.')

add_heading(document, '2.3. NestJS Framework', level=2)
document.add_paragraph('NestJS là framework Node.js được xây dựng để tạo ra các ứng dụng server-side hiệu quả và dễ mở rộng. Nó sử dụng TypeScript mặc định, cung cấp kiến trúc Module rõ ràng và tích hợp sẵn Dependency Injection.')

add_heading(document, '2.4. Hệ quản trị CSDL MySQL', level=2)
document.add_paragraph('MySQL là hệ quản trị cơ sở dữ liệu quan hệ (RDBMS) mã nguồn mở, nổi tiếng về độ ổn định và hiệu năng cao. Trong dự án này, MySQL được sử dụng để lưu trữ toàn bộ dữ liệu về sản phẩm, đơn hàng và người dùng, đảm bảo tính toàn vẹn dữ liệu.')

# --- CHAPTER 3 ---
add_heading(document, 'CHƯƠNG 3: PHÂN TÍCH VÀ THIẾT KẾ HỆ THỐNG', level=1)

add_heading(document, '3.1. Đặc tả yêu cầu (Use Case)', level=2)
document.add_paragraph('Nhóm chức năng Khách hàng:')
document.add_paragraph('- UC01: Đăng ký/Đăng nhập')
document.add_paragraph('- UC02: Tìm kiếm sản phẩm')
document.add_paragraph('- UC03: Quản lý giỏ hàng')
document.add_paragraph('- UC04: Thanh toán (Checkout)')

document.add_paragraph('Nhóm chức năng Quản trị:')
document.add_paragraph('- UC05: Quản lý Sản phẩm')
document.add_paragraph('- UC06: Quản lý Đơn hàng')

add_heading(document, '3.2. Thiết kế Cơ sở dữ liệu (ERD)', level=2)
document.add_paragraph('Hệ thống sử dụng các bảng chính:')
document.add_paragraph('1. users: Lưu thông tin tài khoản')
document.add_paragraph('2. products: Lưu thông tin hàng hóa')
document.add_paragraph('3. orders: Thông tin đơn đặt hàng')
document.add_paragraph('4. order_details: Chi tiết đơn hàng')

# --- CHAPTER 4 ---
add_heading(document, 'CHƯƠNG 4: TRIỂN KHAI VÀ ĐÁNH GIÁ', level=1)

add_heading(document, '4.1. Môi trường cài đặt', level=2)
document.add_paragraph('- Frontend: ReactJS v18')
document.add_paragraph('- Backend: NestJS v9+')
document.add_paragraph('- Database: MySQL 8.0')

add_heading(document, '4.2. Giao diện chương trình', level=2)
document.add_paragraph('(Hình ảnh các giao diện chính đã được triển khai trong ứng dụng)')

add_heading(document, '4.3. Kết quả đạt được', level=2)
document.add_paragraph('- Hệ thống hoạt động ổn định, tốc độ nhanh.')
document.add_paragraph('- Giao diện thân thiện, không lỗi font tiếng Việt.')
document.add_paragraph('- Quy trình mua hàng trơn tru.')

# --- CHAPTER 5 ---
add_heading(document, 'CHƯƠNG 5: KẾT LUẬN', level=1)

add_heading(document, '5.1. Kết luận chung', level=2)
document.add_paragraph('Đồ án đã hoàn thành mục tiêu xây dựng website bán hàng thời trang với đầy đủ tính năng cơ bản. Quá trình thực hiện giúp củng cố kiến thức lập trình Fullstack.')

add_heading(document, '5.2. Hướng phát triển', level=2)
document.add_paragraph('- Phát triển Mobile App (React Native).')
document.add_paragraph('- Tích hợp thanh toán qua ví điện tử.')
document.add_paragraph('- Sử dụng AI để gợi ý sản phẩm.')

document.save('docs/Bao_Cao_Do_An.docx')
